import java.util.Arrays;
/**
 * Write a description of class Poisiton here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Position
{
    int m_r;
    int m_c;
    public Position(int r, int c)
    {
        m_r = r;
        m_c = c;
    }
    public String toString(){
        return "(" + m_r + "," + m_c + ")";
    }
    
    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public static Position findPosition(int num, int[][] intArr)
    {
        for (int row = 0; row < intArr.length; row++){
            for (int col = 0; col < intArr[0].length; col++){
                if(intArr[row][col] == num){
                    return new Position(row, col);
                }
            }
        }
        return null;
    }
    
    public static Position[][] getSuccessorArray(int[][] orgArray){
        Position[][] scsrArray = new Position[orgArray.length][orgArray[0].length];
        for (int row = 0; row < orgArray.length; row++){
            for (int col = 0; col < orgArray[row].length; col++){
                Position m = findPosition(orgArray[row][col] + 1, orgArray);
                scsrArray[row][col] = m;
                if(m != null){
                    System.out.print(m.toString());
                }
                else{
                    System.out.print("null");
                }
                
            }
            System.out.println();
        }
        return scsrArray;
    }
    
   
    public static void main(){
        int mat[][] = { { 1, 12, 4, 11 }, { 9, 3, 2, 10 },{ 7, 5, 8, 6 } };
        //System.out.println(findPosition(12, mat).toString());
        System.out.println(getSuccessorArray(mat));
    }
}





    